# terminalbreaker

***BREAK THE TERMINAL!***

Create panels, forms, dialogs and buttons into your Python CLI app! 