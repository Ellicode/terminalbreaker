<div align="center">
![image](https://user-images.githubusercontent.com/76738069/204636618-c4336079-a9b9-477f-9f7c-6c07a0551dba.png)

# terminalbreaker

[Documentation](https://github.com/Ellicode/terminalbreaker/wiki)

</div>
