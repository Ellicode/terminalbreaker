# terminalbreaker

***BREAK THE TERMINAL!***

[Documentation](docs/README.md)

Create panels, forms, dialogs and buttons into your Python CLI app! 

Install this package with : 
```s
pip install terminalbreaker_pkg
```
https://pypi.org/project/terminalbreaker/

This python library is on beta and i'm working hard to complete it. 🤝

