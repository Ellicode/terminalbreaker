<div align="center">

![screen recording](screenrecord.gif)

## `pip install tbpy`

TerminalBreaker is a python module to create better guis, forms and more.

[Documentation](https://ellicode.github.io/terminalbreaker)

</div>
