from tbpy import *
win = Window("Title of the window", "Hello, world!")
win.mainloop()