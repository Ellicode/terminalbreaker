from __init__ import *
Window(fields=[Field("Hi"), Field("Ew")]).mainloop()