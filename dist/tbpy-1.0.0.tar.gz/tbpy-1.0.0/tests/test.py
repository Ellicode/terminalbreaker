from terminalbreaker import *
win = Window("Title of the window", ["Hello, world!"])
win.mainloop()