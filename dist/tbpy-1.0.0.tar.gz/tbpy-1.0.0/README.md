<div align="center">

![screen recording](screenrecord.gif)

## `pip install terminalbreaker-python`

TerminalBreaker is a python module to create better guis, forms and more.

[Documentation](https://ellicode.github.io/terminalbreaker)

</div>
