# terminalbreaker

***BREAK THE TERMINAL!***

Create panels, forms, dialogs and buttons into your Python CLI app! 

Install this package with : 
```s
pip install terminalbreaker==0.0.2
```
https://pypi.org/project/terminalbreaker/

This python library is on beta and i'm working hard to complete it. Here is my website if you want to learn more (it's in french).